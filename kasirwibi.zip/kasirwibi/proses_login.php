<?php
session_start();
include 'config.php'; // Hubungkan dengan database

// Ambil data dari form
$email = $_POST['email'];
$password = $_POST['password'];

// Cek apakah email dan password ada di database
$query = "SELECT * FROM pengguna WHERE email = '$email' AND password = '$password'";
$result = mysqli_query($db, $query);
$user = mysqli_fetch_assoc($result);

if ($user) {
    // Set session login
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_name'] = $user['nama'];
    

    // Arahkan ke halaman utama
    header("Location: index.php");
    exit();
} else {
    // Login gagal
    echo "<script>alert('Email atau password salah!'); window.location.href='login.php';</script>";
}
?>