<?php
include 'config.php';
session_start();

// Query data penjualan dengan detail produk
$query = "SELECT penjualan.id, penjualan.nama_pelanggan, produk.nama_produk, detail_penjualan.subtotal 
          FROM penjualan 
          JOIN detail_penjualan ON penjualan.kode_transaksi = detail_penjualan.kode_transaksi 
          JOIN produk ON detail_penjualan.produk_id = produk.id 
          ORDER BY penjualan.id DESC";
$result = mysqli_query($db, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Penjualan</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>
<body id="page-top">
    <div id="wrapper">
        <?php include 'sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include 'topbar.php'; ?>
                <div class="container-fluid">
                    <h1 class="h3 mb-4 text-gray-800">Penjualan</h1>

                    <!-- Tombol Aksi -->
                    <button class="btn btn-primary mb-3" data-toggle="modal" data-target="#tambahPenjualanModal">
                        <i class="fas fa-plus"></i> Tambah Penjualan
                    </button>
                    <a href="detail_penjualan.php">
                        <button class="btn btn-info mb-3">
                            <i class="fas fa-eye"></i> Detail
                        </button>
                    </a>

                    <!-- Search Bar -->
                    <div class="form-group">
                        <input type="text" id="searchInput" class="form-control" placeholder="Cari Nama Pelanggan...">
                    </div>

                    <!-- Tabel Penjualan -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Daftar Penjualan</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama Pelanggan</th>
                                            <th>Nama Produk</th>
                                            <th>Subtotal</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $no = 1; while ($row = mysqli_fetch_assoc($result)) { ?>
                                        <tr>
                                            <td><?= $no++; ?></td>
                                            <td><?= htmlspecialchars($row['nama_pelanggan']); ?></td>
                                            <td><?= htmlspecialchars($row['nama_produk']); ?></td>
                                            <td>Rp <?= number_format($row['subtotal'], 0, ',', '.'); ?></td>
                                            <td>
                                                <a href="hapus_penjualan.php?id=<?= $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus transaksi ini?');">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                                <a href="edit_penjualan.php?id=<?= $row['id']; ?>" class="btn btn-warning btn-sm">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal Tambah Penjualan -->
                <div class="modal fade" id="tambahPenjualanModal" tabindex="-1" role="dialog">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <form action="proses_tambah_penjualan.php" method="POST">
                                <div class="modal-header">
                                    <h5 class="modal-title">Tambah Penjualan</h5>
                                    <button class="close" type="button" data-dismiss="modal">
                                        <span>&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <?php $kode_transaksi = "TRX" . date("Ymd") . "-" . rand(100, 999); ?>
                                    <div class="form-group">
                                        <label>Kode Transaksi</label>
                                        <input type="text" name="kode_transaksi" class="form-control" value="<?= $kode_transaksi; ?>" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label>Nama Pelanggan</label>
                                        <input type="text" name="nama_pelanggan" class="form-control" required>
                                    </div>

                                    <div id="produk-container">
                                        <div class="produk-item">
                                            <div class="row">
                                                <div class="col-md-5">
                                                    <label>Produk</label>
                                                    <select class="form-control produk_id" name="produk_id[]" required>
                                                        <option value="">-- Pilih Produk --</option>
                                                        <?php
                                                        $qProduk = mysqli_query($db, "SELECT id, nama_produk, harga FROM produk");
                                                        while ($p = mysqli_fetch_assoc($qProduk)) {
                                                            echo "<option value='{$p['id']}' data-harga='{$p['harga']}'>{$p['nama_produk']} - Rp " . number_format($p['harga'], 0, ',', '.') . "</option>";
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                                <div class="col-md-3">
                                                    <label>Jumlah</label>
                                                    <input type="number" name="jumlah[]" class="form-control jumlah" min="1" value="1" required>
                                                </div>
                                                <div class="col-md-3">
                                                    <label>Subtotal</label>
                                                    <input type="text" name="subtotal[]" class="form-control subtotal" readonly>
                                                </div>
                                                <div class="col-md-1">
                                                    <button type="button" class="btn btn-danger btn-sm mt-4 remove-produk">&times;</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <button type="button" class="btn btn-success btn-sm mt-2" id="tambah-produk">+ Tambah Produk</button>
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Footer -->
                <?php include 'footer.php'; ?>
            </div>
        </div>
    </div>

    <!-- Script -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Script Tambahan -->
    <script>
    document.addEventListener("DOMContentLoaded", function () {
        function hitungSubtotal(produkSelect, jumlahInput, subtotalInput) {
            let harga = produkSelect.options[produkSelect.selectedIndex].getAttribute("data-harga") || 0;
            let jumlah = jumlahInput.value || 1;
            let subtotal = parseInt(harga) * parseInt(jumlah);
            subtotalInput.value = "Rp " + new Intl.NumberFormat('id-ID').format(subtotal);
        }

        function initEventListeners(produkItem) {
            let produkSelect = produkItem.querySelector(".produk_id");
            let jumlahInput = produkItem.querySelector(".jumlah");
            let subtotalInput = produkItem.querySelector(".subtotal");

            produkSelect.addEventListener("change", () => hitungSubtotal(produkSelect, jumlahInput, subtotalInput));
            jumlahInput.addEventListener("input", () => hitungSubtotal(produkSelect, jumlahInput, subtotalInput));
        }

        document.getElementById("tambah-produk").addEventListener("click", function () {
            let produkContainer = document.getElementById("produk-container");
            let newItem = document.querySelector(".produk-item").cloneNode(true);
            newItem.querySelector(".jumlah").value = 1;
            newItem.querySelector(".subtotal").value = "";

            initEventListeners(newItem);

            newItem.querySelector(".remove-produk").addEventListener("click", function () {
                newItem.remove();
            });

            produkContainer.appendChild(newItem);
        });

        document.querySelectorAll(".produk-item").forEach(initEventListeners);

        // FILTER TABLE
        document.getElementById("searchInput").addEventListener("keyup", function () {
            let filter = this.value.toLowerCase();
            let rows = document.querySelectorAll("table tbody tr");

            rows.forEach(row => {
                let namaPelanggan = row.cells[1].textContent.toLowerCase();
                let namaProduk = row.cells[2].textContent.toLowerCase();
                row.style.display = (namaPelanggan.includes(filter) || namaProduk.includes(filter)) ? "" : "none";
            });
        });
    });
    </script>
</body>
</html>
