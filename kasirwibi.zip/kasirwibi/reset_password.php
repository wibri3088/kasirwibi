<?php
$email = $_GET['email'] ?? '';
$pesan = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $koneksi = new mysqli("localhost", "root", "", "saless");

    if ($koneksi->connect_error) {
        die("Koneksi gagal: " . $koneksi->connect_error);
    }

    // Sanitasi input
    $email = mysqli_real_escape_string($koneksi, $_POST['email']);
    $password_baru = $_POST['password'];
    $password_hash = password_hash($password_baru, PASSWORD_DEFAULT);

    // Update password jika email cocok
    $sql = "UPDATE pengguna SET password='$password_hash' WHERE email='$email'";
    if ($koneksi->query($sql) === TRUE && $koneksi->affected_rows > 0) {
        $pesan = "Password berhasil diubah untuk <strong>$email</strong>. <a href='login.php'>Login sekarang</a>";
    } else {
        $pesan = "Gagal mengubah password. Pastikan email terdaftar.";
    }

    $koneksi->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reset Password</title>
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>
<body class="bg-gradient-primary">
<div class="container">
    <div class="row justify-content-center mt-5">
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-header text-center">
                    <h4>Reset Password</h4>
                </div>
                <div class="card-body">
                    <?php if ($pesan): ?>
                        <div class="alert alert-info text-center"><?= $pesan ?></div>
                    <?php else: ?>
                        <form method="POST">
                            <input type="hidden" name="email" value="<?= htmlspecialchars($email) ?>">
                            <div class="form-group">
                                <label>Password Baru</label>
                                <input type="password" name="password" class="form-control" required>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block">Ubah Password</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
