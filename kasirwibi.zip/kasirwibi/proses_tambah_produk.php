<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_produk = $_POST['nama_produk'];
    $kategori_id = $_POST['kategori_id'];
    $harga = $_POST['harga'];
    $stok = isset($_POST['stok']) ? 1 : 0; // Jika dicentang, stok = 1, jika tidak, stok = 0

    $query = "INSERT INTO produk (nama_produk, kategori_id, harga, stok) 
              VALUES ('$nama_produk', '$kategori_id', '$harga', '$stok')";
    
    if (mysqli_query($db, $query)) {
        echo "<script>
                alert('Produk berhasil ditambahkan!');
                window.location.href='produk.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal menambahkan produk!');
                window.location.href='produk.php';
              </script>";
    }
}
?>
