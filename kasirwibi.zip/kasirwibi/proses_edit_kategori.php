<?php
include 'config.php';
session_start();

// Periksa apakah data yang dibutuhkan tersedia
if (!isset($_POST['id']) || !isset($_POST['nama_kategori'])) {
    echo "<script>alert('Data tidak lengkap!'); window.location.href='kategori.php';</script>";
    exit;
}

$id = $_POST['id'];
$nama_kategori = $_POST['nama_kategori'];

// Update data kategori di database
$query = "UPDATE kategori_produk SET nama_kategori = '$nama_kategori' WHERE id = '$id'";
$result = mysqli_query($db, $query);

if ($result) {
    echo "<script>alert('Kategori berhasil diperbarui!'); window.location.href='kategori.php';</script>";
} else {
    echo "<script>alert('Gagal memperbarui kategori!'); window.location.href='kategori.php';</script>";
}
?>
