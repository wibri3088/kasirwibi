<?php
session_start();
include 'config.php'; // Pastikan koneksi database ada

// Cek apakah session pengguna sudah terautentikasi
// if (!isset($_SESSION['user_id'])) {
//     // Redirect ke halaman login jika session belum ada
//     header('Location: login.php');
//     exit();
// }

// Generate kode transaksi unik (misalnya: "TRX-12345")
$kode_transaksi = "TRX-" . rand(10000, 99999);

// Ambil data dari form dan pastikan valid
$nama_pelanggan = isset($_POST['nama_pelanggan']) ? mysqli_real_escape_string($db, $_POST['nama_pelanggan']) : '';
$produk_ids = isset($_POST['produk_id']) ? $_POST['produk_id'] : [];
$jumlahs = isset($_POST['jumlah']) ? $_POST['jumlah'] : [];
$subtotals = isset($_POST['subtotal']) ? $_POST['subtotal'] : [];

// Validasi input, pastikan ada produk yang dipilih
if (empty($produk_ids)) {
    die("Error: Tidak ada produk yang dipilih.");
}

// Validasi subtotal dan produk_id
foreach ($produk_ids as $index => $produk_id) {
    if (empty($produk_id) || !is_numeric($jumlahs[$index]) || $jumlahs[$index] <= 0) {
        die("Error: Data produk atau jumlah tidak valid.");
    }

    // Hapus format "Rp" dan titik pada subtotal
    $subtotal = isset($subtotals[$index]) ? str_replace("Rp ", "", str_replace(".", "", $subtotals[$index])) : 0;
    if (!is_numeric($subtotal) || $subtotal <= 0) {
        die("Error: Subtotal tidak valid.");
    }

    // Pastikan subtotal sesuai dengan harga produk * jumlah
    $query_produk = "SELECT harga FROM produk WHERE id = '$produk_id'";
    $result_produk = mysqli_query($db, $query_produk);

    // Pastikan produk ditemukan di database
    if (mysqli_num_rows($result_produk) == 0) {
        die("Error: Produk dengan ID $produk_id tidak ditemukan.");
    }

    $produk = mysqli_fetch_assoc($result_produk);
    if ($produk['harga'] * $jumlahs[$index] != $subtotal) {
        die("Error: Subtotal tidak sesuai dengan harga produk dan jumlah.");
    }
}

    
// // Simpan transaksi ke tabel penjualan tanpa menyertakan produk_id
// $query_penjualan = "INSERT INTO penjualan (kode_transaksi, nama_pelanggan, jumlah, subtotal) 
//                      VALUES ('$kode_transaksi', '$nama_pelanggan', '$jumlahs', '$subtotal')";
// if (!mysqli_query($db, $query_penjualan)) {
//  die("Error: " . mysqli_error($db));
//  }

// Menghitung total jumlah dari semua produk
$total_jumlah = array_sum($jumlahs);

// Simpan transaksi ke tabel penjualan
$query_penjualan = "INSERT INTO penjualan (kode_transaksi, nama_pelanggan, jumlah, subtotal) 
                     VALUES ('$kode_transaksi', '$nama_pelanggan', '$total_jumlah', '$subtotal')";
if (!mysqli_query($db, $query_penjualan)) {
    die("Error: " . mysqli_error($db));
}



// Masukkan detail penjualan ke tabel detail_penjualan
for ($i = 0; $i < count($produk_ids); $i++) {
    $produk_id = $produk_ids[$i];
    $jumlah = $jumlahs[$i];
    $subtotal = str_replace("Rp ", "", str_replace(".", "", $subtotals[$i])); // Hapus format Rp dan titik
    
    // Masukkan detail transaksi ke tabel detail_penjualan
    $query_detail = "INSERT INTO detail_penjualan (kode_transaksi, produk_id, jumlah, subtotal) 
                     VALUES ('$kode_transaksi', '$produk_id', '$jumlah', '$subtotal')";
    if (!mysqli_query($db, $query_detail)) {
        die("Error: " . mysqli_error($db));
    }

    // Mengurangi stok produk setelah penjualan
    $query_update_stok = "UPDATE produk SET stok = stok - $jumlah WHERE id = $produk_id";
    if (!mysqli_query($db, $query_update_stok)) {
        die("Error: " . mysqli_error($db));
    }
}

// Menampilkan pesan sukses dan mengarahkan pengguna ke halaman penjualan
echo "<script>alert('Transaksi berhasil ditambahkan!'); window.location.href='penjualan.php';</script>";
?>
