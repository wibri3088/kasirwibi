<?php
include 'config.php';
session_start();

// Ambil data produk dan kategori dari database
$query = "SELECT produk.*, kategori_produk.nama_kategori 
          FROM produk 
          JOIN kategori_produk ON produk.kategori_id = kategori_produk.id 
          ORDER BY produk.id DESC";
$result = mysqli_query($db, $query);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produk</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>

<body id="page-top">
    <div id="wrapper">
        <?php include 'sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include 'topbar.php'; ?>
                <div class="container-fluid">
                    <h1 class="h3 mb-4 text-gray-800">Produk</h1>
                    <!-- Tombol Tambah Produk -->
                    <button class="btn btn-primary mb-3" data-toggle="modal" data-target="#tambahProdukModal">
                        <i class="fas fa-plus"></i> Tambah Produk
                    </button>
                    <input type="text" id="searchInput" class="form-control mb-3" placeholder="Cari nama produk...">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Daftar Produk</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama Produk</th>
                                            <th>Kategori</th>
                                            <th>Harga</th>
                                            <th>Stok</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody id="produkTable">
                                        <?php $no = 1; while ($row = mysqli_fetch_assoc($result)) { ?>
                                            <tr>
                                                <td><?= $no++; ?></td>
                                                <td class="nama-produk"><?= htmlspecialchars($row['nama_produk']); ?></td>
                                                <td><?= htmlspecialchars($row['nama_kategori']); ?></td>
                                                <td>Rp <?= number_format($row['harga'], 0, ',', '.'); ?></td>
                                                <td>
                                                    <?php if ($row['stok'] == 1) { ?>
                                                        <span class="badge badge-primary">Tersedia</span>
                                                    <?php } else { ?>
                                                        <span class="badge badge-danger">Tidak Tersedia</span>
                                                    <?php } ?>
                                                </td>
                                                <td>
                                                    <a href="edit_produk.php?id=<?= $row['id']; ?>" class="btn btn-warning btn-sm">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <a href="hapus_produk.php?id=<?= $row['id']; ?>" class="btn btn-danger btn-sm" 
                                                       onclick="return confirm('Yakin ingin menghapus produk ini?');">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include 'footer.php'; ?>
        </div>
    </div>

    <!-- Modal Tambah Produk -->
    <div class="modal fade" id="tambahProdukModal" tabindex="-1" role="dialog" aria-labelledby="tambahProdukModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="tambahProdukModalLabel">Tambah Produk</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Form untuk menambah produk -->
                    <form action="proses_tambah_produk.php" method="POST">
                        <div class="form-group">
                            <label for="nama_produk">Nama Produk</label>
                            <input type="text" class="form-control" id="nama_produk" name="nama_produk" required>
                        </div>
                        <div class="form-group">
                            <label for="kategori_id">Kategori</label>
                            <select class="form-control" id="kategori_id" name="kategori_id" required>
                                <?php
                                $kategoriQuery = "SELECT * FROM kategori_produk";
                                $kategoriResult = mysqli_query($db, $kategoriQuery);
                                while ($kategori = mysqli_fetch_assoc($kategoriResult)) {
                                    echo "<option value='".$kategori['id']."'>".$kategori['nama_kategori']."</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="harga">Harga</label>
                            <input type="number" class="form-control" id="harga" name="harga" required>
                        </div>
                        <div class="form-group">
                            <label for="stok">Stok</label>
                            <input type="number" class="form-control" id="stok" name="stok" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Script JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>

    <script>
        // Fungsi untuk pencarian produk
        document.getElementById("searchInput").addEventListener("keyup", function() {
            let filter = this.value.toLowerCase();
            let rows = document.querySelectorAll("#produkTable tr");
            rows.forEach(row => {
                let namaProduk = row.querySelector(".nama-produk").textContent.toLowerCase();
                row.style.display = namaProduk.includes(filter) ? "" : "none";
            });
        });
    </script>
</body>
</html>
