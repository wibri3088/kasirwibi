<?php
include 'config.php';
session_start();

// Pastikan ada parameter id
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<script>alert('ID kategori tidak ditemukan!'); window.location.href='kategori.php';</script>";
    exit;
}

$id = $_GET['id'];

// Ambil data kategori berdasarkan ID
$query = "SELECT * FROM kategori_produk WHERE id = '$id'";
$result = mysqli_query($db, $query);
$kategori = mysqli_fetch_assoc($result);

if (!$kategori) {
    echo "<script>alert('Kategori tidak ditemukan!'); window.location.href='kategori.php';</script>";
    exit;
}

?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Kategori Produk</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body id="page-top">
    <div id="wrapper">
        <?php include 'sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include 'topbar.php'; ?>
                <div class="container-fluid">
                    <h1 class="h3 mb-4 text-gray-800">Edit Kategori</h1>
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <form action="proses_edit_kategori.php" method="POST">
                                <input type="hidden" name="id" value="<?= $kategori['id']; ?>">
                                <div class="form-group">
                                    <label for="nama_kategori">Nama Kategori</label>
                                    <input type="text" class="form-control" id="nama_kategori" name="nama_kategori" value="<?= $kategori['nama_kategori']; ?>" required>
                                </div>
                                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                                <a href="kategori.php" class="btn btn-secondary">Batal</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php include 'footer.php'; ?>
        </div>
    </div>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
</body>
</html>
