<?php
include 'config.php';
session_start();

// Periksa apakah ada ID produk yang dikirim
if (!isset($_GET['id'])) {
    echo "<script>alert('ID produk tidak ditemukan!'); window.location.href='produk.php';</script>";
    exit;
}

$id = $_GET['id'];

// Ambil data produk berdasarkan ID
$query = "SELECT * FROM produk WHERE id = '$id'";
$result = mysqli_query($db, $query);

if (mysqli_num_rows($result) == 0) {
    echo "<script>alert('Produk tidak ditemukan!'); window.location.href='produk.php';</script>";
    exit;
}

$produk = mysqli_fetch_assoc($result);

// Proses update jika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_produk = $_POST['nama_produk'];
    $kategori_id = $_POST['kategori_id'];
    $harga = $_POST['harga'];
    $stok = isset($_POST['stok']) ? 1 : 0;

    $query_update = "UPDATE produk SET nama_produk='$nama_produk', kategori_id='$kategori_id', harga='$harga', stok='$stok' WHERE id='$id'";
    
    if (mysqli_query($db, $query_update)) {
        echo "<script>alert('Produk berhasil diperbarui!'); window.location.href='produk.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui produk!');</script>";
    }
}

// Ambil data kategori
$query_kategori = "SELECT * FROM kategori_produk";
$result_kategori = mysqli_query($db, $query_kategori);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>
<body id="page-top">
    <div id="wrapper">
        <?php include 'sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include 'topbar.php'; ?>
                <div class="container-fluid">
                    <h1 class="h3 mb-4 text-gray-800">Edit Produk</h1>
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <form action="" method="POST">
                                <div class="form-group">
                                    <label for="nama_produk">Nama Produk</label>
                                    <input type="text" class="form-control" id="nama_produk" name="nama_produk" value="<?= htmlspecialchars($produk['nama_produk']); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="kategori">Kategori</label>
                                    <select class="form-control" id="kategori" name="kategori_id" required>
                                        <option value="">-- Pilih Kategori --</option>
                                        <?php while ($kategori = mysqli_fetch_assoc($result_kategori)) { ?>
                                            <option value="<?= $kategori['id']; ?>" <?= ($kategori['id'] == $produk['kategori_id']) ? 'selected' : ''; ?>>
                                                <?= $kategori['nama_kategori']; ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="harga">Harga</label>
                                    <input type="number" class="form-control" id="harga" name="harga" value="<?= $produk['harga']; ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="stok">Stok</label>
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" id="stok" name="stok" value="1" <?= ($produk['stok'] == 1) ? 'checked' : ''; ?>>
                                        <label class="custom-control-label" for="stok">Tersedia</label>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                                <a href="produk.php" class="btn btn-secondary">Batal</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php include 'footer.php'; ?>
        </div>
    </div>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
</body>
</html>
