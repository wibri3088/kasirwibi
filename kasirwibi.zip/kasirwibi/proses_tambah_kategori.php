<?php
include 'config.php'; // Hubungkan ke database

// Ambil data dari form
$nama_kategori = $_POST['nama_kategori'];

// Validasi agar tidak ada input kosong
if (!empty($nama_kategori)) {
    // Simpan ke database
    $query = "INSERT INTO kategori_produk (nama_kategori) VALUES ('$nama_kategori')";
    
    if (mysqli_query($db, $query)) {
        echo "<script>
                alert('Kategori berhasil ditambahkan!');
                window.location.href='kategori.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal menambahkan kategori!');
                window.location.href='kategori.php';
              </script>";
    }
} else {
    echo "<script>
            alert('Nama kategori tidak boleh kosong!');
            window.location.href='kategori.php';
          </script>";
}
?>
