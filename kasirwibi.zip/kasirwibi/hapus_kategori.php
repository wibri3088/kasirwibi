<?php
include 'config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Hapus produk berdasarkan ID
    $query = "DELETE FROM kategori_produk WHERE id = '$id'";
    $result = mysqli_query($db, $query);

    if ($result) {
        echo "<script>
                alert('Kategori produk berhasil dihapus!');
                window.location.href='kategori.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal menghapus kategori produk!');
                window.location.href='kategori.php';
              </script>";
    }
} else {
    header("Location: produk.php");
}
?>