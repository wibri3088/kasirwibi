<?php
include 'config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Hapus produk berdasarkan ID
    $query = "DELETE FROM penjualan WHERE id = '$id'";
    $result = mysqli_query($db, $query);

    if ($result) {
        echo "<script>
                alert('Produk berhasil dihapus!');
                window.location.href='penjualan.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal menghapus produk!');
                window.location.href='penjualan.php';
              </script>";
    }
} else {
    header("Location: produk.php");
}
?>
