<?php
include 'config.php';
session_start();

// Query to get all data from detail_penjualan table and related tables
$query = "SELECT penjualan.id AS penjualan_id, penjualan.nama_pelanggan, produk.nama_produk, 
                 detail_penjualan.jumlah, detail_penjualan.subtotal
          FROM detail_penjualan
          JOIN penjualan ON penjualan.kode_transaksi = detail_penjualan.kode_transaksi
          JOIN produk ON detail_penjualan.produk_id = produk.id
          ORDER BY penjualan.id DESC, detail_penjualan.id ASC";

// Execute the query and check for errors
$result = mysqli_query($db, $query);
if (!$result) {
    die('Error: ' . mysqli_error($db));
}

?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Penjualan</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <!-- Topbar -->
                <?php include 'topbar.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Detail Penjualan</h1>

                    <!-- Tabel Detail Penjualan -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Daftar Detail Penjualan</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>ID Penjualan</th>
                                            <th>Nama Pelanggan</th>
                                            <th>Nama Produk</th>
                                            <th>Jumlah</th>
                                            <th>Subtotal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $no = 1; 
                                        $total = 0; 
                                        while ($row = mysqli_fetch_assoc($result)) { 
                                        ?>
                                        <tr>
                                            <td><?= $no++; ?></td>
                                            <td><?= htmlspecialchars($row['penjualan_id']); ?></td>
                                            <td><?= htmlspecialchars($row['nama_pelanggan']); ?></td>
                                            <td><?= htmlspecialchars($row['nama_produk']); ?></td>
                                            <td><?= htmlspecialchars($row['jumlah']); ?></td>
                                            <td>Rp <?= number_format($row['subtotal'], 0, ',', '.'); ?></td>
                                        </tr>
                                        <?php 
                                            $total += $row['subtotal']; 
                                        } 
                                        ?>
                                    </tbody>
                                </table>

                                <!-- Display total -->
                                <h4 class="text-right">Total: Rp <?= number_format($total, 0, ',', '.'); ?></h4>
                            </div>
                        </div>
                    </div>

                    <a href="penjualan.php" class="btn btn-secondary">Kembali ke Daftar Penjualan</a>
                </div>
                <!-- End of Page Content -->
            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include 'footer.php'; ?>
            <!-- End of Footer -->
        </div>
        <!-- End of Content Wrapper -->
    </div>
    <!-- End of Page Wrapper -->

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
</body>

</html>
