<?php
include 'config.php';
session_start();

// Ambil ID transaksi dari URL
$id = $_GET['id'];

// Query untuk mengambil data penjualan berdasarkan ID
$query = "SELECT penjualan.*, detail_penjualan.produk_id, detail_penjualan.jumlah, detail_penjualan.subtotal 
          FROM penjualan 
          JOIN detail_penjualan ON penjualan.kode_transaksi = detail_penjualan.kode_transaksi 
          WHERE penjualan.id = '$id'";

$result = mysqli_query($db, $query);
$penjualan = mysqli_fetch_assoc($result);

// Query untuk mengambil data produk
$query_produk = "SELECT id, nama_produk, harga FROM produk";
$produk_result = mysqli_query($db, $query_produk);

// Pastikan ada penjualan yang ditemukan
if (!$penjualan) {
    die("Penjualan tidak ditemukan!");
}



?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Penjualan</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <!-- Topbar -->
                <?php include 'topbar.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800">Edit Penjualan</h1>

                    <!-- Form Edit Penjualan -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Edit Data Penjualan</h6>
                        </div>
                        <div class="card-body">
                            <form action="proses_edit_penjualan.php" method="POST">
                                <input type="hidden" name="id" value="<?= $penjualan['id']; ?>">

                                <div class="form-group">
                                    <label for="kode_transaksi">Kode Transaksi</label>
                                    <input type="text" class="form-control" id="kode_transaksi" name="kode_transaksi" value="<?= $penjualan['kode_transaksi']; ?>" readonly>
                                </div>

                                <div class="form-group">
                                    <label for="nama_pelanggan">Nama Pelanggan</label>
                                    <input type="text" class="form-control" id="nama_pelanggan" name="nama_pelanggan" value="<?= htmlspecialchars($penjualan['nama_pelanggan']); ?>" required>
                                </div>

                                <div id="produk-container">
                                    <?php
                                    // Ambil detail produk
                                    $query_detail = "SELECT produk_id, jumlah, subtotal FROM detail_penjualan WHERE kode_transaksi = '{$penjualan['kode_transaksi']}'";
                                    $detail_result = mysqli_query($db, $query_detail);
                                    while ($detail = mysqli_fetch_assoc($detail_result)) {
                                        $produk = mysqli_fetch_assoc(mysqli_query($db, "SELECT id, nama_produk, harga FROM produk WHERE id = {$detail['produk_id']}"));
                                    ?>
                                    <div class="produk-item">
                                        <div class="row">
                                            <div class="col-md-5">
                                                <label>Produk</label>
                                                <select class="form-control produk_id" name="produk_id[]" required>
                                                    <option value="">-- Pilih Produk --</option>
                                                    <?php
                                                    mysqli_data_seek($produk_result, 0); // Reset pointer
                                                    while ($produk_row = mysqli_fetch_assoc($produk_result)) {
                                                        $selected = ($produk_row['id'] == $detail['produk_id']) ? 'selected' : '';
                                                        echo "<option value='{$produk_row['id']}' data-harga='{$produk_row['harga']}' {$selected}>{$produk_row['nama_produk']} - Rp " . number_format($produk_row['harga'], 0, ',', '.') . "</option>";
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                            <div class="col-md-3">
                                                <label>Jumlah</label>
                                                <input type="number" class="form-control jumlah" name="jumlah[]" min="1" value="<?= $detail['jumlah']; ?>" required>
                                            </div>
                                            <div class="col-md-3">
                                                <label>Subtotal</label>
                                                <input type="text" class="form-control subtotal" name="subtotal[]" value="Rp <?= number_format($detail['subtotal'], 0, ',', '.'); ?>" readonly>
                                            </div>
                                            <div class="col-md-1">
                                                <button type="button" class="btn btn-danger btn-sm mt-4 remove-produk">&times;</button>
                                            </div>
                                        </div>
                                    </div>
                                    <?php } ?>
                                </div>

                                
                                <div class="modal-footer mt-3">
                                    <a href="penjualan.php">

                                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                                    </a>
                                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <script>
                document.addEventListener("DOMContentLoaded", function () {
                    function hitungSubtotal(produkSelect, jumlahInput, subtotalInput) {
                        let harga = produkSelect.options[produkSelect.selectedIndex].getAttribute("data-harga") || 0;
                        let jumlah = jumlahInput.value || 1;
                        let subtotal = parseInt(harga) * parseInt(jumlah);
                        subtotalInput.value = "Rp " + new Intl.NumberFormat('id-ID').format(subtotal);
                    }

                    function initEventListeners(produkItem) {
                        let produkSelect = produkItem.querySelector(".produk_id");
                        let jumlahInput = produkItem.querySelector(".jumlah");
                        let subtotalInput = produkItem.querySelector(".subtotal");

                        produkSelect.addEventListener("change", () => hitungSubtotal(produkSelect, jumlahInput, subtotalInput));
                        jumlahInput.addEventListener("input", () => hitungSubtotal(produkSelect, jumlahInput, subtotalInput));
                    }

                    document.getElementById("tambah-produk").addEventListener("click", function () {
                        let produkContainer = document.getElementById("produk-container");
                        let newProdukItem = document.querySelector(".produk-item").cloneNode(true);
                        newProdukItem.querySelector(".jumlah").value = 1;
                        newProdukItem.querySelector(".subtotal").value = "";

                        initEventListeners(newProdukItem);
                        
                        newProdukItem.querySelector(".remove-produk").addEventListener("click", function () {
                            newProdukItem.remove();
                        });

                        produkContainer.appendChild(newProdukItem);
                    });

                    document.querySelectorAll(".produk-item").forEach(initEventListeners);
                });
                </script>

            </div>
        </div>
    </div>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
</body>
</html>

