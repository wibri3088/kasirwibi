<?php
include 'config.php';

// Ambil ID penjualan dan data produk yang baru
$id = $_POST['id'];
$kode_transaksi = $_POST['kode_transaksi'];
$nama_pelanggan = $_POST['nama_pelanggan'];
$produk_id = $_POST['produk_id'];
$jumlah = $_POST['jumlah'];

// Update data penjualan
$query = "UPDATE penjualan SET nama_pelanggan = '$nama_pelanggan' WHERE id = '$id'";
mysqli_query($db, $query);

// Hapus detail penjualan lama
$query_delete_detail = "DELETE FROM detail_penjualan WHERE kode_transaksi = '$kode_transaksi'";
mysqli_query($db, $query_delete_detail);

// Insert ulang detail penjualan
foreach ($produk_id as $index => $produk) {
    $jumlah_produk = $jumlah[$index];
    $harga = mysqli_fetch_assoc(mysqli_query($db, "SELECT harga FROM produk WHERE id = '$produk'"))['harga'];
    $subtotal = $harga * $jumlah_produk;
    
    $query_insert_detail = "INSERT INTO detail_penjualan (kode_transaksi, produk_id, jumlah, subtotal) 
                            VALUES ('$kode_transaksi', '$produk', '$jumlah_produk', '$subtotal')";
    mysqli_query($db, $query_insert_detail);
}

header("Location: penjualan.php");
exit;
